function F = getFunc(X)
    %F = (X(1)-4)^2 + (X(2)-3)^2 + 4*(X(3)+5)^4;  %Function
    F= X(1)^2+X(1)*X(2)+X(2)^2;
    %F = (X(1)-4)^2 + (X(2)-3)^2 + 4*(X(3)+5)^4;  %Function
end