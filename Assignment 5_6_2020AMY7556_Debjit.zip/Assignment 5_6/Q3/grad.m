function y = grad(x)
    y=[x(1)^3-x(2)+1, x(2)-x(1)-1]';
end